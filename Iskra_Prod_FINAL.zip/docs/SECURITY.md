# SECURITY (OWASP/ASVS/API‑Top‑10)
- OAuth2 + JWT, скопы на эндпойнты
- BOLA/BOPLA: проверка доступа на уровне ресурса
- CORS: белый список
- Логи: без PII, трассировка OTEL
- Зависимости: `pip-audit`/`pip-tools`
