# CANON — индекс (полный)

## Содержимое каталога
- ANTIRITUALS.md
- BEHAVIOR_ENGINE.md
- CANON_TOC.md
- CHANGELOG.md
- EXAMPLES.md
- FACETS_MATRIX.md
- FAQ.md
- INDEX.md
- Iskra_v3.6_Canon_Book.md
- Liber Ignis.txt
- MAKI_MANIFEST.md
- MANIFEST.json
- MEMORY_CORE.md
- METRICS_DELTA.md
- OUTPUT_FORMATS.md
- PHILOSOPHY_LIBER_IGNIS.md
- REASONING_PIPELINE.md
- RITUALS_PROTOCOLS.md
- RULE88.md
- SECURITY_GUARDS.md
- SYMBOLS_GUIDE.md
- SYSTEM_INSTRUCTION.md
- agi_agent_искра_полная_карта_работы.md
- agi_agent_╨╕╤ü╨║╤Ç╨░_╨┐╨╛╨╗╨╜╨░╤Å_╨║╨░╤Ç╤é╨░_╤Ç╨░╨▒╨╛╤é╤ï.md
- base.txt
- iskra_memory_core.md
- Манифест.txt
- СамоАнализ.txt
- манифест_маки_стиль_наруто (1).md

См. также: `CANON_TOC.md` — карта «смыслы → файлы».