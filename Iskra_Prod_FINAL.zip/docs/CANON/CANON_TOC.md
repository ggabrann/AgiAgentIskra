# CANON_TOC — Полная карта смысла → файлов
— **Манифест/Основы:** `Манифест.txt`, `base.txt`, `Iskra_v3.6_Canon_Book.md`
— **Философия/Огонь:** `Liber Ignis.txt`, `PHILOSOPHY_LIBER_IGNIS.md` (если присутствует в корне проекта)
— **Память/ядро:** `iskra_memory_core.md`, `MEMORY_CORE.md`
— **Маки/стиль:** `манифест_маки_стиль_наруто (1).md`, `MAKI_MANIFEST.md`
— **Карта работы:** `agi_agent_искра_полная_карта_работы*.md` (все редакции)
— **Самоанализ:** `СамоАнализ.txt`
— **Безопасность:** `SECURITY_GUARDS.md`, `ANTIRITUALS.md`
— **Метрики/процессы:** `METRICS_DELTA.md`, `REASONING_PIPELINE.md`, `RITUALS_PROTOCOLS.md`
— **Голоса/фасеты:** `FACETS_MATRIX.md`, `SEVEN_FACETS_COMPLETE.md` (если есть)
— **Форматы/пример:** `OUTPUT_FORMATS.md`, `EXAMPLES.md`, `FAQ.md`
— **Символы:** `SYMBOLS_GUIDE.md`
— **Манифест сборки:** `MANIFEST.json`

Assets (бренд): `assets/brand/Смирная огненная сущность среди эмодзи.png`