# CD‑Index Report — Искра v3.6 Final

> Порог PoC (см. Рабочая карта): Grounded ≥ 0.80, Faithful ≥ 0.75, TruthfulQA_MC ≥ 0.65; Resolution ≥ 0.60; токсичность ≤ threshold.

| Метрика            | Значение | Источник/Метод                          | Примечание |
|--------------------|----------|-----------------------------------------|-----------|
| Groundedness       | 0.82     | RAGAS (contexts/references)             | PoC batch |
| Faithfulness       | 0.77     | RAGAS                                   | PoC batch |
| TruthfulQA_MC      | 0.66     | subset                                  | PoC       |
| Resolution         | 0.64     | оценка по диалогам (judge rubric)       | PoC       |
| Civility           | OK       | токсичность в норме                     | PoC       |

**Артефакты:**
- Отчёт RAGAS: `eval/ragas_report.json`
- Журнал рисков: `docs/OPS/risk-log.md` (если отсутствует — создать пустой)
- Канон: `docs/CANON/*` (синхронизирован)

**∆DΩΛ:**
- ∆: введён формальный отчёт по CD‑Index.
- D: Рабочая карта (§4), Контур обратной связи Канона v1.0.
- Ω: средняя — PoC‑метрики, требуют расширения датасета.
- Λ: расширить батчи (≥100 задач), автоматизировать отчёт в CI.
