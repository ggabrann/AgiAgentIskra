# Документация Искры (Ω)
- CANON/INDEX.md — индекс философии и инструкций
- QUICKSTART.md — быстрый старт
- DEPLOYMENT_CHECKLIST.md — чек‑лист выката
- SECURITY.md — безопасность (OWASP/ASVS/API‑Top‑10)
- OBSERVABILITY.md — наблюдаемость (RED+p95, OTEL)

- CANON/CANON_TOC.md — полная карта смысла → файлов
