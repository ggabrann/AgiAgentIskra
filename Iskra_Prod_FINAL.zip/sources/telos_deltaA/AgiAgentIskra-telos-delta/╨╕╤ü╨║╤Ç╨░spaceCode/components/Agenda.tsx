import React, { useState, useMemo } from 'react';
import type { Task, Habit } from '../types';
import { Tasks } from './Tasks';
import { Habits } from './Habits';
import { Calendar } from './Calendar';
import { TaskDiagram } from './TaskDiagram';

interface AgendaProps {
    tasks: Task[];
    habits: Habit[];
    onAddTask: (text: string) => void;
    onToggleTask: (id: number) => void;
    onAddHabit: (text: string) => void;
    onToggleHabit: (id: number) => void;
}

type AgendaView = 'list' | 'calendar' | 'diagram';

export const Agenda: React.FC<AgendaProps> = ({ tasks, habits, onAddTask, onToggleTask, onAddHabit, onToggleHabit }) => {
    const [activeView, setActiveView] = useState<AgendaView>('list');
    const [newHabitText, setNewHabitText] = useState('');
    const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);

    const handleAddHabitSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (newHabitText.trim()) {
            onAddHabit(newHabitText);
            setNewHabitText('');
        }
    };
    
    const filteredTasks = useMemo(() => {
        if (activeView === 'calendar' && selectedDate) {
            return tasks.filter(task => task.dueDate === selectedDate);
        }
        return tasks;
    }, [tasks, activeView, selectedDate]);


    return (
        <div className="space-y-6">
            {/* View Switcher */}
            <div className="flex justify-center bg-bg/50 p-1.5 rounded-lg border border-border w-fit mx-auto">
                <button
                    onClick={() => setActiveView('list')}
                    className={`px-4 py-1.5 rounded-md text-sm font-semibold transition-colors ${activeView === 'list' ? 'bg-accent text-bg' : 'text-textPrimary hover:bg-border/50'}`}
                >
                    📋 Список
                </button>
                <button
                    onClick={() => setActiveView('calendar')}
                    className={`px-4 py-1.5 rounded-md text-sm font-semibold transition-colors ${activeView === 'calendar' ? 'bg-accent text-bg' : 'text-textPrimary hover:bg-border/50'}`}
                >
                    📅 Календарь
                </button>
                <button
                    onClick={() => setActiveView('diagram')}
                    className={`px-4 py-1.5 rounded-md text-sm font-semibold transition-colors ${activeView === 'diagram' ? 'bg-accent text-bg' : 'text-textPrimary hover:bg-border/50'}`}
                >
                    📊 Диаграммы
                </button>
            </div>

            {/* Content based on view */}
            {activeView === 'list' && (
                <div className="space-y-8">
                    <div>
                        <h3 className="font-serif text-xl text-textPrimary mb-4">🎯 Задачи</h3>
                        <Tasks tasks={tasks} onToggle={onToggleTask} onAdd={onAddTask} />
                    </div>
                     <div>
                        <h3 className="font-serif text-xl text-textPrimary mb-4">🔄 Привычки</h3>
                        <Habits habits={habits} onToggle={onToggleHabit} />
                         <form onSubmit={handleAddHabitSubmit} className="mt-4 flex gap-2">
                            <input
                                type="text"
                                value={newHabitText}
                                onChange={(e) => setNewHabitText(e.target.value)}
                                placeholder="Новая привычка..."
                                className="flex-1 bg-bg/50 border-2 border-border rounded-lg py-2 px-3 text-textSecondary placeholder-slate-400 focus:ring-2 focus:ring-accent focus:border-accent transition-all duration-200"
                            />
                            <button
                                type="submit"
                                className="bg-accent hover:opacity-90 disabled:opacity-50 text-bg font-bold py-2 px-4 rounded-lg transition-all"
                                disabled={!newHabitText.trim()}
                            >
                                +
                            </button>
                        </form>
                    </div>
                </div>
            )}
            {activeView === 'calendar' && (
                 <div className="space-y-6">
                    <Calendar 
                        tasks={tasks}
                        selectedDate={selectedDate}
                        setSelectedDate={setSelectedDate}
                    />
                    <div>
                         <h3 className="font-serif text-xl text-textPrimary mb-4">
                            Задачи на {new Date(selectedDate).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' })}
                        </h3>
                        <Tasks tasks={filteredTasks} onToggle={onToggleTask} onAdd={onAddTask} filterDate={selectedDate} />
                    </div>
                 </div>
            )}
            {activeView === 'diagram' && <TaskDiagram tasks={tasks} />}
        </div>
    );
};