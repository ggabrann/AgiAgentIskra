import React from 'react';
// Fix: Corrected import path for type definitions.
import type { Quest, Achievement } from '../types';
import { Achievements } from './Achievements';

interface QuestsProps {
    quests: Quest[];
    achievements: Achievement[];
}

const QuestItem: React.FC<{ quest: Quest }> = ({ quest }) => {
    const progressPercentage = (quest.progress / quest.goal) * 100;

    return (
        <div className={`border-l-4 p-4 rounded-r-lg ${quest.isComplete ? 'border-accent bg-accent/10' : 'border-border bg-bg/30'}`}>
            <div className="flex justify-between items-start mb-2">
                <div>
                    <h4 className={`font-bold ${quest.isComplete ? 'text-accent' : 'text-textPrimary'}`}>{quest.title}</h4>
                    <p className="text-sm text-textSecondary">{quest.description}</p>
                </div>
                <span className={`text-xs font-bold py-1 px-2 rounded-full ${quest.type === 'daily' ? 'bg-sky-800/70 text-sky-300' : 'bg-purple-800/70 text-purple-300'}`}>
                    {quest.type === 'daily' ? 'Дневной' : 'Недельный'}
                </span>
            </div>
            <div className="flex items-center space-x-3 mt-3">
                <div className="progress-bar w-full h-2.5">
                    <div className="progress-bar-fill" style={{ width: `${progressPercentage}%` }}></div>
                </div>
                <span className="text-sm font-semibold text-textSecondary w-12 text-right">
                    {quest.progress}/{quest.goal}
                </span>
            </div>
        </div>
    );
};

export const Quests: React.FC<QuestsProps> = ({ quests, achievements }) => {
    const personalQuests = quests.filter(q => q.scope === 'personal');
    const dailyQuests = personalQuests.filter(q => q.type === 'daily');
    const weeklyQuests = personalQuests.filter(q => q.type === 'weekly');

    return (
        <div className="space-y-8">
            <div>
                <h3 className="font-serif text-xl text-textSecondary mb-3">Дневные Ритуалы</h3>
                <div className="space-y-3">
                    {dailyQuests.length > 0 ? dailyQuests.map(quest => <QuestItem key={quest.id} quest={quest} />) : <p className="text-sm text-slate-400">Нет дневных ритуалов.</p>}
                </div>
            </div>
             <div>
                <h3 className="font-serif text-xl text-textSecondary mb-3">Недельные Ритуалы</h3>
                <div className="space-y-3">
                    {weeklyQuests.length > 0 ? weeklyQuests.map(quest => <QuestItem key={quest.id} quest={quest} />) : <p className="text-sm text-slate-400">Нет недельных ритуалов.</p>}
                </div>
            </div>
            <div>
                 <h3 className="font-serif text-xl text-textSecondary mb-3">Достижения</h3>
                 <Achievements achievements={achievements} />
            </div>
        </div>
    );
};