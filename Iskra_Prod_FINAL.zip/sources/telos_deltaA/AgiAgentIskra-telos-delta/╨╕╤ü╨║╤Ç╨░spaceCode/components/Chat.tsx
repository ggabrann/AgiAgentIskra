import React, { useState, useEffect, useRef, useCallback } from 'react';
// Fix: Corrected import path for type definitions.
import type { Partner, ChatMessage, RhythmData } from '../types';
import * as encryptionService from '../services/encryptionService';
import * as firebaseService from '../services/firebaseService';
import { getDuoInsight } from '../services/geminiService';

interface ChatProps {
    currentUser: { id: string, name: string };
    partner: Partner;
    rhythmData: RhythmData;
}

const Spinner: React.FC<{ size?: 'small' | 'large'}> = ({ size = 'large' }) => (
    <div className={`flex justify-center items-center ${size === 'large' ? 'p-4' : ''}`}>
        <svg className={`animate-spin text-accent ${size === 'large' ? 'h-6 w-6' : 'h-5 w-5'}`} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
    </div>
);

export const Chat: React.FC<ChatProps> = ({ currentUser, partner, rhythmData }) => {
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [decryptedMessages, setDecryptedMessages] = useState<Map<string, string>>(new Map());
    const [newMessage, setNewMessage] = useState('');
    const [sharedSecret, setSharedSecret] = useState<CryptoKey | null>(null);
    const [status, setStatus] = useState('Initializing...');
    const chatEndRef = useRef<HTMLDivElement>(null);

    const [suggestion, setSuggestion] = useState<string | null>(null);
    const [isLoadingSuggestion, setIsLoadingSuggestion] = useState(false);

    const scrollToBottom = () => {
        chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    useEffect(() => {
        scrollToBottom();
    }, [decryptedMessages]);

    // Initialize encryption session
    const setupEncryption = useCallback(async () => {
        setStatus('Создание защищённого канала...');
        
        let userKeys = await encryptionService.getKeysForUser(currentUser.id);
        if (!userKeys) {
            userKeys = await encryptionService.generateKeys();
            await encryptionService.storeKeysForUser(currentUser.id, userKeys);
            const exported = await encryptionService.exportKeys(userKeys);
            firebaseService.publishPublicKey(currentUser.id, exported.publicKey);
        }
        
        let partnerPublicKey = await firebaseService.fetchPublicKey(partner.id);
        if (!partnerPublicKey) {
            setStatus(`Ожидание ключа от ${partner.name}...`);
            const partnerKeys = await encryptionService.generateKeys();
            const exportedPartnerKey = await encryptionService.exportKeys(partnerKeys);
            firebaseService.publishPublicKey(partner.id, exportedPartnerKey.publicKey);
            await encryptionService.storeKeysForUser(partner.id, partnerKeys); 
            partnerPublicKey = exportedPartnerKey.publicKey;
        }

        const secret = await encryptionService.deriveSharedSecret(userKeys.privateKey, partnerPublicKey);
        setSharedSecret(secret);
        setStatus('');
    }, [currentUser.id, partner.id, partner.name]);

    useEffect(() => {
        setupEncryption();
    }, [setupEncryption]);

    // Listen for incoming messages
    useEffect(() => {
        if (!sharedSecret) return;
        const unsubscribe = firebaseService.onMessagesSnapshot(currentUser.id, partner.id, setMessages);
        return () => unsubscribe();
    }, [sharedSecret, currentUser.id, partner.id]);

    // Decrypt messages
    useEffect(() => {
        if (!sharedSecret || messages.length === 0) return;
        const decryptAll = async () => {
            const newDecrypted = new Map(decryptedMessages);
            let updated = false;
            for (const msg of messages) {
                if (!newDecrypted.has(msg.id)) {
                    const decryptedText = await encryptionService.decryptMessage(msg.ciphertext, msg.iv, sharedSecret);
                    newDecrypted.set(msg.id, decryptedText);
                    updated = true;
                }
            }
            if (updated) setDecryptedMessages(newDecrypted);
        };
        decryptAll();
    }, [messages, sharedSecret, decryptedMessages]);

    const handleSendMessage = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!newMessage.trim() || !sharedSecret) return;
        const { ciphertext, iv } = await encryptionService.encryptMessage(newMessage, sharedSecret);
        firebaseService.sendMessage({ senderId: currentUser.id, receiverId: partner.id, ciphertext, iv });
        setNewMessage('');
        setSuggestion(null);
    };

    const handleGetSuggestion = async () => {
        setIsLoadingSuggestion(true);
        setSuggestion(null);
        try {
            const duoInsight = await getDuoInsight(rhythmData, partner);
            setSuggestion(duoInsight);
        } catch (error) {
            console.error("Failed to get duo insight:", error);
            setSuggestion("Просто спроси, как дела :)");
        } finally {
            setIsLoadingSuggestion(false);
        }
    };


    if (status) {
        return (
             <div className="flex-1 flex flex-col justify-center items-center">
                <Spinner />
                <p className="text-sm text-textSecondary mt-2">{status}</p>
            </div>
        )
    }

    return (
        <div className="flex-1 flex flex-col h-[60vh]">
             <div className="p-2 text-center border-b border-border/50">
                <p className="text-sm text-textSecondary/80">
                    Это начало вашего зашифрованного чата с <span className="font-semibold text-textPrimary">{partner.name}</span>.
                </p>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
                {messages.map((msg) => {
                    const isSender = msg.senderId === currentUser.id;
                    const text = decryptedMessages.get(msg.id) || 'Расшифровка...';
                    return (
                        <div key={msg.id} className={`flex items-end gap-2 ${isSender ? 'justify-end' : 'justify-start'}`}>
                           <div className={`flex flex-col ${isSender ? 'items-end' : 'items-start'}`}>
                                <div className={`chat-bubble p-3 ${isSender ? 'sender' : 'receiver'}`}>
                                    <p>{text}</p>
                                </div>
                                <p className="text-xs text-slate-400 mt-1 px-1">
                                    {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                </p>
                            </div>
                        </div>
                    );
                })}
                 <div ref={chatEndRef} />
            </div>
            {(isLoadingSuggestion || suggestion) && (
                <div className="p-2 px-4">
                     <div className="bg-border/30 border-l-4 border-accent rounded-r-lg p-3 flex items-center justify-between">
                        {isLoadingSuggestion ? <Spinner size="small" /> : <p className="text-sm italic text-textSecondary/90 flex-1">{suggestion}</p>}
                        {!isLoadingSuggestion && suggestion && (
                            <button onClick={() => { setNewMessage(suggestion); setSuggestion(null); }} className="ml-3 text-xs font-bold bg-accent text-bg px-2.5 py-1 rounded-md hover:opacity-80 transition-opacity">
                                Сказать
                            </button>
                        )}
                    </div>
                </div>
            )}
            <div className="p-2 border-t border-border/50">
                <form onSubmit={handleSendMessage} className="flex items-center gap-2">
                    <button
                        type="button"
                        onClick={handleGetSuggestion}
                        disabled={isLoadingSuggestion}
                        className="p-2 text-2xl text-accent rounded-lg hover:bg-border/50 transition-colors disabled:opacity-50"
                        aria-label="Get AI suggestion"
                    >
                       ✨
                    </button>
                    <input
                        type="text"
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        placeholder="Написать сообщение..."
                        className="flex-1 bg-bg/50 border-2 border-border rounded-lg py-2 px-4 text-textSecondary placeholder-slate-400 focus:ring-2 focus:ring-accent focus:border-accent transition-all duration-200"
                        aria-label="New message"
                    />
                    <button
                        type="submit"
                        disabled={!newMessage.trim()}
                        className="bg-accent hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold p-2.5 rounded-lg transition-all duration-200 shadow-[0_0_15px_-5px_var(--tw-color-accent)]"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                            <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" />
                        </svg>
                    </button>
                </form>
            </div>
        </div>
    );
};