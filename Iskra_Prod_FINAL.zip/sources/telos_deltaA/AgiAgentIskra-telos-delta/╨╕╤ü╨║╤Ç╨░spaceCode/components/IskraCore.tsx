import React from 'react';
// Fix: Corrected import path for type definitions.
import type { IskraState, IskraMetric } from '../types';

interface IskraCoreProps {
    iskraState: IskraState;
}

const CircularProgress: React.FC<{ progress: number; color: string; }> = ({ progress, color }) => {
    const radius = 54;
    const circumference = 2 * Math.PI * radius;
    const offset = circumference - (progress / 100) * circumference;

    return (
        <svg width="140" height="140" viewBox="0 0 140 140" className="-rotate-90">
            <circle
                cx="70"
                cy="70"
                r={radius}
                fill="none"
                stroke="currentColor"
                strokeWidth="8"
                className="text-border"
            />
            <circle
                cx="70"
                cy="70"
                r={radius}
                fill="none"
                stroke={color}
                strokeWidth="8"
                strokeLinecap="round"
                strokeDasharray={circumference}
                strokeDashoffset={offset}
                className="transition-all duration-500 ease-out"
            />
        </svg>
    );
};

const MetricBar: React.FC<{ metric: IskraMetric }> = ({ metric }) => (
    <div className="flex items-center gap-4">
        <span className="w-20 text-sm font-medium text-textSecondary/80">{metric.description}</span>
        <div className="flex-1 bg-border/50 rounded-full h-2.5">
            <div
                className="h-2.5 rounded-full"
                style={{ width: `${metric.value}%`, backgroundColor: metric.color }}
            ></div>
        </div>
        <span className="w-10 text-sm font-semibold text-right" style={{color: metric.color}}>{metric.value}%</span>
    </div>
);


export const IskraCore: React.FC<IskraCoreProps> = ({ iskraState }) => {
    const { trust, clarity, drift, pain, chaos, phase } = iskraState;

    return (
        <div className="space-y-6">
            <div className="text-center">
                <h2 className="font-serif text-2xl font-bold text-textPrimary">Ядро Искры</h2>
                <p className="text-sm text-textSecondary/70">Симуляция живого состояния и телесных давлений.</p>
            </div>
            
            <div className="flex flex-col items-center justify-center p-4">
                <div className="relative">
                    <CircularProgress progress={trust.value} color={trust.color} />
                    <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                         <span className="text-3xl text-accent animate-symbol-pulse">⟡</span>
                         <h3 className="text-lg font-bold text-textPrimary mt-1">Искра</h3>
                         <p className="text-[10px] text-textSecondary/80">Фаза: {phase}</p>
                    </div>
                </div>
            </div>

            <div className="space-y-4 px-2">
                <div title="Доверие: Насколько система уверена в своих действиях и данных.">
                    <MetricBar metric={trust} />
                </div>
                <div title="Ясность: Насколько ясны цели и задачи пользователя.">
                    <MetricBar metric={clarity} />
                </div>
                <div title="Дрейф: Отклонение от первоначальных целей и планов.">
                    <MetricBar metric={drift} />
                </div>
                <div title="Боль: Уровень стресса, конфликтов или препятствий.">
                    <MetricBar metric={pain} />
                </div>
                <div title="Хаос: Степень непредсказуемости и отсутствия структуры.">
                    <MetricBar metric={chaos} />
                </div>
            </div>

             <div className="text-center mt-6 p-4 border border-border border-dashed rounded-lg">
                <p className="text-sm text-textSecondary">
                   Состояние ядра динамически изменяется, отражая внутренние процессы Искры.
                </p>
            </div>
        </div>
    );
};