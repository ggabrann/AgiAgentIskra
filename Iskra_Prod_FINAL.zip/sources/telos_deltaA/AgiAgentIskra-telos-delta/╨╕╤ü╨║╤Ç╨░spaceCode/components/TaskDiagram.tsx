import React, { useMemo } from 'react';
import type { Task, RitualMark } from '../types';

interface TaskDiagramProps {
    tasks: Task[];
}

const ritualMarkDetails: Record<RitualMark, { name: string; color: string }> = {
    '🜂': { name: 'Огонь (Действие)', color: '#FF4D4F' },
    '⟡': { name: 'Вода (Рефлексия)', color: '#3EA8FF' },
    '☉': { name: 'Солнце (Создание)', color: '#FFC700' },
    '≈': { name: 'Баланс (Отношения)', color: '#40C463' },
    '∆': { name: 'Ритм (Развитие)', color: '#8B5CF6' },
};

export const TaskDiagram: React.FC<TaskDiagramProps> = ({ tasks }) => {
    const distribution = useMemo(() => {
        const totalTasks = tasks.length;
        if (totalTasks === 0) return [];

        const counts: Record<string, number> = {};
        let untaggedCount = 0;

        tasks.forEach(task => {
            if (task.ritualMark) {
                counts[task.ritualMark] = (counts[task.ritualMark] || 0) + 1;
            } else {
                untaggedCount++;
            }
        });
        
        const result = Object.entries(counts).map(([mark, count]) => ({
            mark: mark as RitualMark,
            count,
            percentage: Math.round((count / totalTasks) * 100),
        }));

        if (untaggedCount > 0) {
            result.push({
                mark: 'Untagged' as any,
                count: untaggedCount,
                percentage: Math.round((untaggedCount / totalTasks) * 100),
            });
        }
        
        return result.sort((a, b) => b.count - a.count);

    }, [tasks]);

    if (tasks.length === 0) {
        return (
            <div className="text-center p-8 bg-bg/30 rounded-lg border border-dashed border-border">
                <p className="text-textSecondary">Нет задач для анализа.</p>
                <p className="text-sm text-slate-400 mt-2">Добавьте задачи с ритуальными метками, чтобы увидеть диаграмму.</p>
            </div>
        );
    }

    return (
        <div className="space-y-4">
            <h3 className="font-serif text-xl text-textPrimary text-center">Распределение задач по меткам</h3>
            <div className="bg-bg/30 p-4 rounded-lg space-y-3">
                {distribution.map(({ mark, count, percentage }) => {
                    const details = mark !== 'Untagged' ? ritualMarkDetails[mark] : { name: 'Без метки', color: '#A9B4C2' };
                    return (
                        <div key={mark} className="flex items-center gap-4">
                            <div className="w-1/3 flex items-center">
                                <span className="text-2xl mr-2">{mark !== 'Untagged' ? mark : '🏷️'}</span>
                                <span className="text-sm font-semibold text-textSecondary">{details.name}</span>
                            </div>
                            <div className="flex-1">
                                <div className="h-4 rounded-full" style={{ backgroundColor: `${details.color}20` }}>
                                    <div 
                                        className="h-4 rounded-full transition-all duration-500"
                                        style={{ width: `${percentage}%`, backgroundColor: details.color, boxShadow: `0 0 8px ${details.color}` }}
                                    ></div>
                                </div>
                            </div>
                            <div className="w-16 text-right font-mono text-sm" style={{ color: details.color }}>
                                {percentage}%
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};