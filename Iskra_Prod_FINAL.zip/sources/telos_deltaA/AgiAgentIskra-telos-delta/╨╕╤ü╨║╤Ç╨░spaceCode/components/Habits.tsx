import React from 'react';
import type { Habit } from '../types';

interface HabitsProps {
    habits: Habit[];
    onToggle: (id: number) => void;
}

export const Habits: React.FC<HabitsProps> = ({ habits, onToggle }) => {
    return (
        <div>
            {habits.length > 0 ? (
                 <ul className="space-y-3">
                    {habits.map((habit) => (
                        <li key={habit.id} className="flex items-center">
                             <input
                                type="checkbox"
                                id={`habit-${habit.id}`}
                                checked={habit.completed}
                                onChange={() => onToggle(habit.id)}
                                className={`h-5 w-5 rounded-md appearance-none bg-border/60 border-2 border-border text-accent focus:ring-accent focus:ring-offset-surface focus:ring-2 cursor-pointer transition-all duration-300 mr-4 checked:bg-accent checked:border-transparent checked:shadow-[0_0_12px_var(--tw-color-accent)]`}
                                aria-labelledby={`habit-label-${habit.id}`}
                            />
                            <label
                                htmlFor={`habit-${habit.id}`}
                                id={`habit-label-${habit.id}`}
                                className={`w-full cursor-pointer transition-colors duration-300 text-base ${
                                    habit.completed ? 'text-slate-500 line-through' : 'text-textSecondary'
                                }`}
                            >
                                {habit.text}
                            </label>
                        </li>
                    ))}
                </ul>
            ) : (
                <div className="text-center py-4 text-slate-400">
                    <p>Добавьте привычки, чтобы отслеживать прогресс.</p>
                </div>
            )}
        </div>
    );
};