// Fix: Corrected import path for type definitions.
import type { ChatMessage } from '../types';

// --- Simulation of Firebase Firestore ---

const PUBLIC_KEYS_COLLECTION = 'iskra-publicKeys';
const MESSAGES_COLLECTION = 'iskra-messages';
const CHAT_UPDATE_EVENT = 'iskra-chat-update';

// --- Public Key Management ---

export const publishPublicKey = (userId: string, publicKey: JsonWebKey): void => {
    try {
        const keys = JSON.parse(localStorage.getItem(PUBLIC_KEYS_COLLECTION) || '{}');
        keys[userId] = publicKey;
        localStorage.setItem(PUBLIC_KEYS_COLLECTION, JSON.stringify(keys));
        console.log(`Public key for ${userId} published.`);
    } catch (e) {
        console.error("Failed to publish public key:", e);
    }
};

export const fetchPublicKey = (userId: string): Promise<JsonWebKey | null> => {
    return new Promise((resolve) => {
        setTimeout(() => { // Simulate network delay
            try {
                const keys = JSON.parse(localStorage.getItem(PUBLIC_KEYS_COLLECTION) || '{}');
                resolve(keys[userId] || null);
            } catch (e) {
                console.error("Failed to fetch public key:", e);
                resolve(null);
            }
        }, 300);
    });
};


// --- Message Management ---

export const sendMessage = (message: Omit<ChatMessage, 'id' | 'timestamp'>): void => {
     try {
        const messages: ChatMessage[] = JSON.parse(localStorage.getItem(MESSAGES_COLLECTION) || '[]');
        const newMessage: ChatMessage = {
            ...message,
            id: `msg-${Date.now()}-${Math.random()}`,
            timestamp: Date.now(),
        };
        messages.push(newMessage);
        localStorage.setItem(MESSAGES_COLLECTION, JSON.stringify(messages));
        
        // Dispatch event to notify listeners of a new message
        window.dispatchEvent(new CustomEvent(CHAT_UPDATE_EVENT));
    } catch (e) {
        console.error("Failed to send message:", e);
    }
};

// --- Real-time Listener Simulation ---

type Unsubscribe = () => void;

export const onMessagesSnapshot = (
    userId1: string, 
    userId2: string, 
    callback: (messages: ChatMessage[]) => void
): Unsubscribe => {
    
    const getMessages = () => {
        try {
            const allMessages: ChatMessage[] = JSON.parse(localStorage.getItem(MESSAGES_COLLECTION) || '[]');
            const relevantMessages = allMessages.filter(msg => 
                (msg.senderId === userId1 && msg.receiverId === userId2) ||
                (msg.senderId === userId2 && msg.receiverId === userId1)
            );
            callback(relevantMessages.sort((a, b) => a.timestamp - b.timestamp));
        } catch (e) {
            console.error("Failed to get messages:", e);
            callback([]);
        }
    };
    
    // Initial fetch
    getMessages();

    // Set up listener
    const handleUpdate = () => {
        console.log("Chat update event received.");
        getMessages();
    };

    window.addEventListener(CHAT_UPDATE_EVENT, handleUpdate);

    // Return an unsubscribe function
    return () => {
        console.log("Unsubscribing from chat updates.");
        window.removeEventListener(CHAT_UPDATE_EVENT, handleUpdate);
    };
};