# Память Искры
ARCHIVE/SHADOW схемы, Rule‑8/88.
