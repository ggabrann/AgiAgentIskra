DROP INDEX IF EXISTS emb_ivf;
CREATE INDEX emb_ivf ON embeddings USING ivfflat (embedding vector_cosine_ops) WITH (lists=1000);
ANALYZE embeddings;
