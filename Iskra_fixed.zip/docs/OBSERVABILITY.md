# OBSERVABILITY (RED + p95, OpenTelemetry)
- RED: Rate/Errors/Duration на /v1/search и /v1/chat
- p95 латентности — ключевая метрика SLO
- Трассировка: opentelemetry-instrumentation-fastapi, экспорт OTLP
