# QUICKSTART
1) Установите зависимости:
```
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```
2) Поднимите API:
```
make -C ops api-run  # http://127.0.0.1:8000
```
3) Поднимите БД с pgvector:
```
docker compose up -d
```
4) Загрузите корпус и эмбеддинги:
```
python scripts/load_corpus.py --root ./docs --dsn "${PG_DSN:-dbname=postgres user=postgres password=postgres host=127.0.0.1 port=5432}"
```
5) Бенч:
```
export MANIFEST_DIR=$(pwd)/manifest
python bench/pgvector_bench.py
```
6) RAGAS:
```
python eval/ragas_eval.py --pred eval/predictions.jsonl --ref eval/references.jsonl --ctx eval/contexts.jsonl
```
