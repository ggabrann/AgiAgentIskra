DROP INDEX IF EXISTS emb_hnsw;
CREATE INDEX emb_hnsw ON embeddings USING hnsw (embedding vector_cosine_ops) WITH (m = 16, ef_construction = 64);
-- Set at query time:
-- SET hnsw.ef_search = 32; -- or 64 / 128
