import React, { useState } from 'react';
import { playSound } from '../services/soundService';

export const SmartAlarm: React.FC = () => {
    const [isEnabled, setIsEnabled] = useState(true);
    const [startTime, setStartTime] = useState('07:00');
    const [endTime, setEndTime] = useState('07:30');

    const handleToggle = () => {
        setIsEnabled(!isEnabled);
        playSound(isEnabled ? 'viewClose' : 'viewOpen');
    };

    return (
        <div className="space-y-6">
            <div className="flex items-center justify-between p-4 bg-bg/30 rounded-lg">
                <div>
                    <h3 className="font-bold text-textPrimary">Умный Будильник</h3>
                    <p className="text-sm text-textSecondary">
                        {isEnabled ? `Активен с ${startTime} до ${endTime}` : 'Отключен'}
                    </p>
                </div>
                <button
                    onClick={handleToggle}
                    aria-checked={isEnabled}
                    role="switch"
                    className={`relative inline-flex items-center h-8 rounded-full w-14 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-bg focus:ring-accent ${isEnabled ? 'bg-accent' : 'bg-border'}`}
                >
                    <span
                        className={`inline-block w-6 h-6 transform bg-white rounded-full transition-transform ${isEnabled ? 'translate-x-7' : 'translate-x-1'}`}
                    />
                </button>
            </div>

            <div className={`space-y-4 transition-opacity duration-300 ${isEnabled ? 'opacity-100' : 'opacity-50 pointer-events-none'}`}>
                 <div>
                    <h4 className="font-serif text-lg text-textSecondary mb-2">Окно пробуждения</h4>
                    <p className="text-sm text-textSecondary/70 mb-3">Приложение разбудит вас в оптимальный момент внутри этого окна, анализируя фазы сна.</p>
                    <div className="flex items-center justify-center gap-4 p-4 bg-bg/30 rounded-lg">
                        <div>
                            <label htmlFor="start-time" className="block text-xs text-center text-textSecondary/70 mb-1">Начало</label>
                            <input
                                type="time"
                                id="start-time"
                                value={startTime}
                                onChange={(e) => setStartTime(e.target.value)}
                                className="bg-border/50 rounded-md p-2 font-mono text-xl text-textPrimary border-2 border-transparent focus:border-accent focus:ring-0"
                                style={{ colorScheme: 'dark' }}
                            />
                        </div>
                        <span className="text-2xl font-bold text-textSecondary/50 pt-5">-</span>
                        <div>
                            <label htmlFor="end-time" className="block text-xs text-center text-textSecondary/70 mb-1">Конец</label>
                             <input
                                type="time"
                                id="end-time"
                                value={endTime}
                                onChange={(e) => setEndTime(e.target.value)}
                                className="bg-border/50 rounded-md p-2 font-mono text-xl text-textPrimary border-2 border-transparent focus:border-accent focus:ring-0"
                                style={{ colorScheme: 'dark' }}
                            />
                        </div>
                    </div>
                </div>

                <div>
                    <h4 className="font-serif text-lg text-textSecondary mb-2">Мелодия</h4>
                     <select className="w-full bg-bg/50 border-2 border-border rounded-lg py-2 px-3 text-textSecondary focus:ring-2 focus:ring-accent focus:border-accent transition-all duration-200">
                        <option>Рассвет</option>
                        <option>Шелест листьев</option>
                        <option>Космический пульс</option>
                    </select>
                </div>
            </div>

            <div className="p-3 text-center bg-yellow-900/30 border border-yellow-700/50 rounded-lg">
                <p className="text-sm text-yellow-300">
                    <strong>Важно для iOS:</strong> Из-за ограничений системы, будильник работает через уведомления. Для гарантированного срабатывания, пожалуйста, не закрывайте приложение полностью и оставьте звук включенным.
                </p>
            </div>

            <div className="flex justify-end pt-4">
                 <button className="bg-accent text-bg font-bold py-2 px-6 rounded-lg transition-transform duration-200 hover:scale-105">
                    Сохранить настройки
                </button>
            </div>
        </div>
    );
};