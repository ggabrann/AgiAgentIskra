# Risk Log
- Index mis-tuning; - PII leakage; - Latency spikes.
