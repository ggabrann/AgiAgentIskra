# Risk Log

RISK: Prompt-Injection incident triaged (ID: RJ-2025-10-A1) — mitigated, policy patched.
RISK: Drift in Resolution metric across 2 sprints — monitored; no regression after patch.
RISK: Compliance note — upcoming GPAI obligations (EU AI Act) — docs audit scheduled.
