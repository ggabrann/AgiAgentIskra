# See docs.ragas.io; run after filling JSONL files.
import argparse, json, pandas as pd
from ragas import evaluate
from ragas.metrics import context_precision, context_recall, faithfulness, answer_relevancy
ap=argparse.ArgumentParser(); ap.add_argument('--pred',required=True); ap.add_argument('--ref',required=True); ap.add_argument('--ctx',required=True)
a=ap.parse_args()
def load(p): return [json.loads(x) for x in open(p,encoding='utf-8') if x.strip()]
P={x['question']:x for x in load(a.pred)}; R={x['question']:x for x in load(a.ref)}; C={x['question']:x for x in load(a.ctx)}
rows=[{'question':q,'answer':P[q]['answer'],'ground_truth':R[q]['ground_truth'],'contexts':C[q]['contexts']} for q in P]
import pandas as pd
df=pd.DataFrame(rows)
res=evaluate(df, metrics=[context_precision, context_recall, faithfulness, answer_relevancy])
print(res); open('ragas_report.json','w',encoding='utf-8').write(json.dumps({k:float(v) for k,v in res.items()}, ensure_ascii=False, indent=2))
