# Искра — продакшен‑сборка (Ω)

Готовый комплект для запуска и релиза: API (FastAPI), RAG‑оценка (RAGAS), бенчи pgvector (HNSW/IVFFlat), CI‑гейт Canon, Docker‑сборка, Model Card, Risk Log, Evidence Map.

## Быстрый старт (локально)
```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
make -C ops api-run  # http://127.0.0.1:8000/healthz
```

## Docker / Compose
```bash
docker compose up -d  # Postgres+pgvector и API
```

## Бенчи pgvector
```bash
export MANIFEST_DIR=$(pwd)/manifest
python bench/pgvector_bench.py
```

## RAGAS mini‑оценка (10 запросов)
Заполните `eval/predictions.jsonl`, `eval/references.jsonl`, `eval/contexts.jsonl`, затем:
```bash
python eval/ragas_eval.py --pred eval/predictions.jsonl --ref eval/references.jsonl --ctx eval/contexts.jsonl
```

## Канон‑гейт (CI)
Блокирует релиз, если CD‑Index ниже порога, p95 выше SLO, или метрики RAGAS провалены. Порог фиксируется в `manifest/cd_index_baseline.json`.


### CANON
Документы канона: см. `docs/CANON/INDEX.md`.
