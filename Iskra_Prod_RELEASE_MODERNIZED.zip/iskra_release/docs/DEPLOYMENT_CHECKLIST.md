# DEPLOYMENT CHECKLIST
- [ ] ENV‑переменные из `.env`/секретов CI загружены
- [ ] Postgres 16 + pgvector установлен / docker compose работает
- [ ] Созданы индексы HNSW/IVFFlat согласно гриду
- [ ] OpenTelemetry включён, p95‑алерты заведены
- [ ] Canon‑гейт (CI) проходит: CD‑Index ≥ baseline
- [ ] Model Card / Risk Log / Evidence Map актуальны
