# Iskra — Model Card (vΩ)
