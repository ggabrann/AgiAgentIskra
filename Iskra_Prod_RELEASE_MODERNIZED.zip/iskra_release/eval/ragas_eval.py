import argparse, json
from datasets import Dataset
from ragas import evaluate
from ragas.metrics import faithfulness, answer_relevancy, context_precision, context_recall

def load_jsonl(p):
    return [json.loads(line) for line in open(p,"r",encoding="utf-8") if line.strip()]

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--pred", required=True); ap.add_argument("--ref", required=True); ap.add_argument("--ctx", required=True)
    args = ap.parse_args()
    pred, ref, ctx = load_jsonl(args.pred), load_jsonl(args.ref), load_jsonl(args.ctx)
    ds = Dataset.from_list([{"question": p.get("question"), "answer": p.get("answer"), "contexts": c.get("contexts", []), "ground_truth": r.get("ground_truth")} for p,r,c in zip(pred,ref,ctx)])
    res = evaluate(ds, [faithfulness, answer_relevancy, context_precision, context_recall])
    open("ragas_report.json","w",encoding="utf-8").write(res.to_pandas().to_json(orient="records", force_ascii=False, indent=2))
    print("Done: ragas_report.json")
