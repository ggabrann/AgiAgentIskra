

## 2025-10-26 — TEL̄OS-Δ интегрирован в канон (gate v1)
∆: Добавлен контур Canon Review (TEL̄OS-Δ); пороги v0 в CI; шаблон `canon/canon_review.md`.
D: baseline v0, юнит-тест `canon_review_test.py`, CD-Index v0.
Ω: высокий — тест зелёный, пороги соблюдены.
Λ: ≤24ч — подготовить `cd-index_v1.json` и `risk-log.md`; включить stage `canon_review` в CI.
