import React, { useState, useMemo } from 'react';
import type { Task } from '../types';

interface TasksProps {
    tasks: Task[];
    onToggle: (id: number) => void;
    onAdd: (text: string) => void;
    filterDate?: string | null; // Optional prop to filter by date
}

export const Tasks: React.FC<TasksProps> = ({ tasks, onToggle, onAdd, filterDate = null }) => {
    const [newTaskText, setNewTaskText] = useState('');

    const handleAdd = (e: React.FormEvent) => {
        e.preventDefault();
        if (newTaskText.trim()) {
            onAdd(newTaskText);
            setNewTaskText('');
        }
    };

    const displayedTasks = useMemo(() => {
        if (filterDate) {
            return tasks.filter(task => task.dueDate === filterDate);
        }
        return tasks;
    }, [tasks, filterDate]);

    return (
        <div className="p-4 sm:p-5">
            {displayedTasks.length > 0 ? (
                <ul className="space-y-3">
                    {displayedTasks.map((task) => (
                        <li key={task.id} className="flex items-center group">
                            <input
                                type="checkbox"
                                id={`task-${task.id}`}
                                checked={task.completed}
                                onChange={() => onToggle(task.id)}
                                className="custom-checkbox mr-4"
                                aria-labelledby={`task-label-${task.id}`}
                            />
                            <label
                                htmlFor={`task-${task.id}`}
                                id={`task-label-${task.id}`}
                                className={`w-full cursor-pointer transition-colors duration-300 text-base ${
                                    task.completed ? 'text-slate-500 line-through' : 'text-textSecondary'
                                }`}
                            >
                                {task.text}
                            </label>
                            <span className={`text-xs font-bold px-2 py-1 rounded-full transition-all duration-200 ${
                                task.priority === 'High' ? 'bg-danger/10 text-danger/70 group-hover