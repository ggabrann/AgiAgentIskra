import React from 'react';

export const Canvas: React.FC = () => {
  return (
    <div className="space-y-4">
      <h3 className="font-serif text-xl text-textPrimary">🎨 Canvas / Mind Map</h3>
      <div className="p-4 bg-bg/30 rounded-lg border border-dashed border-border text-center h-64 flex flex-col justify-center items-center">
        <p className="text-textSecondary">Здесь будет бесконечный холст для ваших идей.</p>
        <p className="text-sm text-slate-400 mt-2">Функциональность в разработке.</p>
        <div className="mt-4 text-4xl animate-pulse">🧠 ✨ 📝</div>
      </div>
    </div>
  );
};