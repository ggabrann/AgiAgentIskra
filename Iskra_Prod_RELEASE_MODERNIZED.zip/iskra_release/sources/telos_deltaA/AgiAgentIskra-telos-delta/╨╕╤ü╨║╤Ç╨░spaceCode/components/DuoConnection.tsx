import React, { useState } from 'react';
// Fix: Corrected import path for type definitions.
import type { Partner, Quest } from '../types';
import { Chat } from './Chat';

interface DuoConnectionProps {
    partner: Partner;
    onOpenChat: () => void;
    quests: Quest[];
}

const PrivacyToggle: React.FC<{ label: string; isEnabled: boolean; onToggle: () => void; }> = ({ label, isEnabled, onToggle }) => (
    <div className="flex items-center justify-between text-sm py-1">
        <span className="text-textSecondary">{label}</span>
        <button
            onClick={onToggle}
            aria-checked={isEnabled}
            role="switch"
            className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-bg focus:ring-accent ${isEnabled ? 'bg-accent' : 'bg-border'}`}
        >
            <span
                className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform ${isEnabled ? 'translate-x-6' : 'translate-x-1'}`}
            />
        </button>
    </div>
);

const DuoQuestItem: React.FC<{ quest: Quest }> = ({ quest }) => {
    const progressPercentage = (quest.progress / quest.goal) * 100;
    return (
        <div className="bg-bg/40 p-3 rounded-lg border border-border/50">
            <p className="text-sm font-semibold text-textPrimary truncate">{quest.title}</p>
            <div className="flex items-center space-x-2 mt-1.5">
                <div className="progress-bar w-full h-1.5 bg-border/50">
                    <div className="progress-bar-fill h-full" style={{ width: `${progressPercentage}%` }}></div>
                </div>
                <span className="text-xs font-mono text-textSecondary">{quest.progress}/{quest.goal}</span>
            </div>
        </div>
    );
}

export const DuoConnection: React.FC<DuoConnectionProps> = ({ partner, onOpenChat, quests }) => {
    // Mock state for privacy settings
    const [shareSleep, setShareSleep] = useState(true);
    const [sharePulse, setSharePulse] = useState(false);
    const [shareSteps, setShareSteps] = useState(true);
    
    const duoQuests = quests.filter(q => q.scope === 'duo');

    return (
        <div className="space-y-4">
            {/* Partner Status */}
            <div className="flex items-center">
                <span className="text-4xl mr-3">{partner.statusEmoji}</span>
                <div>
                    <p className="font-bold text-textPrimary">{partner.name}</p>
                    <p className="text-sm text-textSecondary">Ритм: {partner.rhythmIndex}% | Сон: {partner.sleep}</p>
                </div>
            </div>
            
            {/* Shared Goals */}
            <div>
                 <h4 className="font-semibold text-sm text-textSecondary/80 mb-2">Совместные цели</h4>
                 <div className="space-y-2">
                     {duoQuests.length > 0 ? (
                        duoQuests.map(q => <DuoQuestItem key={q.id} quest={q} />)
                     ) : (
                        <p className="text-xs text-center p-3 bg-bg/40 rounded-lg text-textSecondary/60">Нет совместных целей. Создайте их в разделе Ритуалов!</p>
                     )}
                 </div>
            </div>

            {/* Shared Canvas */}
            <div className="bg-bg/40 p-3 rounded-lg border border-border/50 flex items-center justify-between">
                <div className="flex items-center">
                     <span className="text-2xl mr-3">🎨</span>
                     <h4 className="font-semibold text-sm text-textPrimary">Общий Canvas</h4>
                </div>
                 <button className="text-xs font-bold text-accent hover:brightness-125 transition">Открыть &rarr;</button>
            </div>

            {/* Privacy Settings */}
            <div>
                 <h4 className="font-semibold text-sm text-textSecondary/80 mb-2">Настройки приватности</h4>
                 <div className="space-y-1 bg-bg/40 p-3 rounded-lg border border-border/50">
                     <PrivacyToggle label="Сон (агрегаты)" isEnabled={shareSleep} onToggle={() => setShareSleep(p => !p)} />
                     <PrivacyToggle label="Пульс (live)" isEnabled={sharePulse} onToggle={() => setSharePulse(p => !p)} />
                     <PrivacyToggle label="Шаги (неделя)" isEnabled={shareSteps} onToggle={() => setShareSteps(p => !p)} />
                 </div>
            </div>

            {/* CTA */}
            <button 
                onClick={onOpenChat}
                className="w-full bg-accent hover:opacity-90 text-bg font-bold py-2.5 px-4 rounded-lg transition-all duration-200 shadow-[0_0_15px_-5px_var(--tw-color-accent)] text-sm flex items-center justify-center"
            >
                <span className="mr-2 text-lg">💬</span> Чат-ритуал
            </button>
        </div>
    );
};