import React from 'react';
// Fix: Corrected import path for type definitions.
import type { Achievement } from '../types';

interface AchievementsProps {
    achievements: Achievement[];
}

const AchievementItem: React.FC<{ achievement: Achievement }> = ({ achievement }) => {
    return (
        <div 
            className={`relative flex flex-col items-center justify-center text-center p-4 border rounded-lg aspect-square transition-all duration-300 group
                ${achievement.isUnlocked 
                    ? 'border-accent/50 bg-accent/10 glow-accent' 
                    : 'border-border bg-bg/30 opacity-40'
                }`
            }
        >
            <span className={`text-4xl font-serif transition-transform duration-300 ${achievement.isUnlocked ? 'group-hover:scale-110' : ''}`}>
                {achievement.symbol}
            </span>
            <h4 className={`font-bold mt-2 text-sm ${achievement.isUnlocked ? 'text-textPrimary' : 'text-textSecondary'}`}>
                {achievement.title}
            </h4>
            {achievement.isUnlocked && (
                <div className="absolute inset-0 bg-bg/90 rounded-lg p-3 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <p className="text-xs text-textSecondary leading-snug">{achievement.description}</p>
                </div>
            )}
        </div>
    );
};

export const Achievements: React.FC<AchievementsProps> = ({ achievements }) => {
    return (
        <div className="grid grid-cols-3 gap-4">
            {achievements.map(achievement => (
                <AchievementItem key={achievement.id} achievement={achievement} />
            ))}
        </div>
    );
};