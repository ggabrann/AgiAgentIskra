import React from 'react';
import type { Task, Habit } from '../types';

interface AgendaSummaryProps {
    tasks: Task[];
    habits: Habit[];
    onNavigate: () => void;
}

export const AgendaSummary: React.FC<AgendaSummaryProps> = ({ tasks, habits, onNavigate }) => {
    const today = new Date().toISOString().split('T')[0];
    const todaysTasks = tasks.filter(t => t.dueDate === today);
    const incompleteTasksCount = todaysTasks.filter(t => !t.completed).length;
    const completedHabitsCount = habits.filter(h => h.completed).length;

    return (
        <div className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div className="flex-1 grid grid-cols-2 gap-4">
                    <div className="bg-bg/30 p-4 rounded-lg text-center">
                        <p className="text-3xl font-bold text-textPrimary">{incompleteTasksCount}</p>
                        <p className="text-sm text-textSecondary mt-1">задач на сегодня</p>
                    </div>
                    <div className="bg-bg/30 p-4 rounded-lg text-center">
                        <p className="text-3xl font-bold text-textPrimary">{completedHabitsCount}/{habits.length}</p>
                        <p className="text-sm text-textSecondary mt-1">привычек выполнено</p>
                    </div>
                </div>
            </div>
            <button
                onClick={onNavigate}
                className="w-full bg-accent/10 border-2 border-accent/30 text-accent font-bold py-3 px-4 rounded-lg transition-all duration-200 hover:bg-accent/20 hover:border-accent/50 text-base"
            >
                Перейти к повестке дня &rarr;
            </button>
        </div>
    );
};