import React, { useState, useEffect } from 'react';
import { getProactiveInsight } from '../services/geminiService';
import type { CognitiveState, RhythmData, Task } from '../types';

interface AdaptiveHeaderProps {
    cognitiveState: CognitiveState;
    rhythmData: RhythmData;
    tasks: Task[];
}

const timeOfDayInfo: Record<CognitiveState, { icon: string; greeting: string; }> = {
    morning: { icon: '🌅', greeting: 'Утро' },
    focus: { icon: '☀️', greeting: 'День' },
    evening: { icon: '🌙', greeting: 'Вечер' },
    rest: { icon: '🌌', greeting: 'Ночь' },
};

export const AdaptiveHeader: React.FC<AdaptiveHeaderProps> = ({ cognitiveState, rhythmData, tasks }) => {
    const [insight, setInsight] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchInsight = async () => {
            setIsLoading(true);
            try {
                const proactiveInsight = await getProactiveInsight(rhythmData, cognitiveState, tasks);
                setInsight(proactiveInsight);
            } catch (error) {
                console.error("Failed to get proactive insight:", error);
                // Fallback message
                const defaultMessages = {
                    morning: 'Что сегодня зажжёт твою искру?',
                    focus: 'Время сконцентрироваться и творить.',
                    evening: 'Момент для паузы и взгляда внутрь.',
                    rest: 'Спокойной ночи и ясных снов.'
                };
                setInsight(defaultMessages[cognitiveState]);
            } finally {
                setIsLoading(false);
            }
        };

        fetchInsight();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [cognitiveState]); // Rerun only when the cognitive state changes

    const timeInfo = timeOfDayInfo[cognitiveState];

    return (
        <div className="text-center min-h-[8rem] flex flex-col justify-center">
            <h2 className="text-4xl font-serif text-textPrimary">{timeInfo.icon} {timeInfo.greeting}</h2>
            <div className="mt-2 text-textSecondary h-10 flex items-center justify-center">
                 {isLoading ? (
                    <div className="animate-spin h-5 w-5 text-accent"></div>
                 ) : (
                    <p className="context-message italic text-sm">{insight}</p>
                 )}
            </div>
        </div>
    );
};