import React, { useState, useMemo } from 'react';
import type { Task } from '../types';

interface CalendarProps {
    tasks: Task[];
    selectedDate: string;
    setSelectedDate: (date: string) => void;
}

const daysOfWeek = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];

export const Calendar: React.FC<CalendarProps> = ({ tasks, selectedDate, setSelectedDate }) => {
    const [currentMonth, setCurrentMonth] = useState(new Date());

    const startOfMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), 1);
    const endOfMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 0);
    const startDate = new Date(startOfMonth);
    const startDayOfWeek = (startDate.getDay() + 6) % 7; // Monday is 0
    startDate.setDate(startDate.getDate() - startDayOfWeek);

    const endDate = new Date(endOfMonth);
    const endDayOfWeek = (endDate.getDay() + 6) % 7;
    endDate.setDate(endDate.getDate() + (6 - endDayOfWeek));

    const dates = [];
    for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
        dates.push(new Date(d));
    }
    
    const taskDates = useMemo(() => {
        const dateSet = new Set<string>();
        tasks.forEach(task => {
            if (task.dueDate) {
                dateSet.add(task.dueDate);
            }
        });
        return dateSet;
    }, [tasks]);

    const handlePrevMonth = () => {
        setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1, 1));
    };

    const handleNextMonth = () => {
        setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 1));
    };
    
    const todayISO = new Date().toISOString().split('T')[0];

    return (
        <div className="bg-bg/30 p-4 rounded-lg">
            <div className="flex justify-between items-center mb-4">
                <button onClick={handlePrevMonth} className="p-2 rounded-md hover:bg-border transition-colors">&lt;</button>
                <h3 className="font-serif text-xl text-textPrimary capitalize">
                    {currentMonth.toLocaleDateString('ru-RU', { month: 'long', year: 'numeric' })}
                </h3>
                <button onClick={handleNextMonth} className="p-2 rounded-md hover:bg-border transition-colors">&gt;</button>
            </div>
            <div className="grid grid-cols-7 gap-1 text-center text-xs font-semibold text-textSecondary/70 mb-2">
                {daysOfWeek.map(day => <div key={day}>{day}</div>)}
            </div>
            <div className="grid grid-cols-7 gap-1">
                {dates.map((date, index) => {
                    const dateISO = date.toISOString().split('T')[0];
                    const isCurrentMonth = date.getMonth() === currentMonth.getMonth();
                    const isToday = dateISO === todayISO;
                    const isSelected = dateISO === selectedDate;
                    const hasTasks = taskDates.has(dateISO);

                    const dayClasses = [
                        'relative h-12 flex items-center justify-center rounded-md transition-colors cursor-pointer',
                        isCurrentMonth ? 'text-textSecondary' : 'text-textSecondary/30',
                        isToday && 'font-bold text-accent border-2 border-accent/50',
                        isSelected ? 'bg-accent/30' : 'hover:bg-border/50',
                    ].filter(Boolean).join(' ');

                    return (
                        <div key={index} className={dayClasses} onClick={() => setSelectedDate(dateISO)}>
                            <span>{date.getDate()}</span>
                            {hasTasks && <div className="absolute bottom-1.5 w-1.5 h-1.5 bg-accent rounded-full"></div>}
                        </div>
                    );
                })}
            </div>
        </div>
    );
};