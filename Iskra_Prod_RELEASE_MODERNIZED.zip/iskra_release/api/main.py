from fastapi import FastAPI, HTTPException, Depends, Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import os, time, jwt
from datetime import datetime, timedelta

try:
    from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
except Exception:
    FastAPIInstrumentor = None

JWT_SECRET = os.getenv("JWT_SECRET", "dev-secret")
CORS_ORIGINS = os.getenv("CORS_ORIGINS", "http://localhost:3000").split(",")

app = FastAPI(title="Iskra API", version="0.2.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
if FastAPIInstrumentor:
    FastAPIInstrumentor.instrument_app(app)

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"

class LoginRequest(BaseModel):
    username: str
    password: str

def create_token(subject: str, minutes: int = 60) -> str:
    payload = {"sub": subject, "exp": datetime.utcnow() + timedelta(minutes=minutes), "iat": datetime.utcnow()}
    return jwt.encode(payload, JWT_SECRET, algorithm="HS256")

def require_auth(authorization: Optional[str] = Header(default=None)) -> str:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="Missing token")
    token = authorization.split(" ",1)[1]
    try:
        data = jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
        return data["sub"]
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid token")

class SearchRequest(BaseModel):
    query: str
    k: int = 5

class Chunk(BaseModel):
    doc_id: str
    score: float
    content: str

class SearchResponse(BaseModel):
    query: str
    chunks: List[Chunk]
    latency_ms: float

class ChatRequest(BaseModel):
    message: str
    topk: int = 4

class ChatResponse(BaseModel):
    reply: str
    citations: List[Chunk] = []
    cd_index: Optional[float] = None

@app.get("/healthz")
def healthz():
    return {"status": "ok", "time": time.time()}

@app.post("/auth/login", response_model=Token)
def login(req: LoginRequest):
    return Token(access_token=create_token(req.username))

@app.post("/v1/search", response_model=SearchResponse)
def search(req: SearchRequest, user: str = Depends(require_auth)):
    t0 = time.perf_counter()
    chunks = [Chunk(doc_id="demo", score=1.0, content="demo content")]
    dt = (time.perf_counter() - t0) * 1000
    return SearchResponse(query=req.query, chunks=chunks, latency_ms=dt)

@app.post("/v1/chat", response_model=ChatResponse)
def chat(req: ChatRequest, user: str = Depends(require_auth)):
    reply = f"Эхо: {req.message}"
    return ChatResponse(reply=reply, citations=[])

from pathlib import Path
import json

@app.get("/v1/version")
def version():
    manifest = Path("manifest/cd_index_baseline.json")
    comp = json.loads(manifest.read_text(encoding="utf-8")) if manifest.exists() else {}
    return {"name":"Iskra Ω","version":"2025-10-29","components": comp.get("components",{}),"cd_index": comp.get("cd_index")}

@app.get("/v1/canon/index")
def canon_index():
    p = Path("docs/CANON/INDEX.md")
    return {"lines": p.read_text(encoding="utf-8").splitlines() if p.exists() else []}
