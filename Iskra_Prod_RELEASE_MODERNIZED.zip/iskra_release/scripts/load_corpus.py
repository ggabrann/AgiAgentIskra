import os, argparse, glob
import psycopg2
from psycopg2.extras import execute_values

def chunks(text, max_len=800):
    words, cur, buf = text.split(), 0, []
    for w in words:
        buf.append(w); cur += len(w) + 1
        if cur >= max_len: yield " ".join(buf); cur, buf = 0, []
    if buf: yield " ".join(buf)

def embed_many(texts, random_mode=False):
    if random_mode:
        import numpy as np
        return [np.random.rand(1536).astype("float32") for _ in texts]
    from sentence_transformers import SentenceTransformer
    m = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
    return m.encode(texts, convert_to_numpy=True, normalize_embeddings=True)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--dsn", required=True)
    ap.add_argument("--random", action="store_true")
    args = ap.parse_args()

    paths = glob.glob(os.path.join(args.root, "**/*.md"), recursive=True) + glob.glob(os.path.join(args.root, "**/*.txt"), recursive=True)
    rows = []
    for p in paths:
        text = open(p,"r",encoding="utf-8",errors="ignore").read()
        doc_id = os.path.relpath(p, args.root)
        for i, ch in enumerate(chunks(text)):
            rows.append((doc_id, i, ch))
    contents = [r[2] for r in rows]
    vecs = embed_many(contents, random_mode=args.random)

    with psycopg2.connect(args.dsn) as conn, conn.cursor() as cur:
        cur.execute("CREATE EXTENSION IF NOT EXISTS vector;")
        cur.execute("CREATE TABLE IF NOT EXISTS embeddings(id SERIAL PRIMARY KEY, doc_id TEXT, chunk_id INT, content TEXT, embedding VECTOR(1536));")
        data = [(r[0], r[1], r[2], list(vec)) for r, vec in zip(rows, vecs)]
        execute_values(cur, "INSERT INTO embeddings (doc_id, chunk_id, content, embedding) VALUES %s", data, template="(%s,%s,%s,%s)")
        conn.commit()
    print(f"Loaded chunks: {len(rows)}")

if __name__ == "__main__":
    main()
