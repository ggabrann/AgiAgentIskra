# Валидатор

- drift > 0.3 → аудит Искрива.
- clarity < 0.7 → активировать Сэма.
- pain > 0.7 → вызвать Кайна.
- echo выше порога → ритуал Shatter.
- chaos > 0.6 → Phoenix/Хуньдун.

Smoke-кейсы см. `tests/validator_cases.md`.
