import json
from pathlib import Path

inp = Path("canon/canon_review_input.json")
if not inp.exists():
    print("No input; skipping decide (treat as KEEP)")
    Path("canon/decision.json").write_text(json.dumps({"verdict": "KEEP", "reason": "no_input"}), encoding="utf-8")
else:
    data = json.loads(inp.read_text(encoding="utf-8"))
    cd = data["cd_index"]
    hist = cd.get("CDIndexHistory", [])
    threshold = cd["Baselines"]["CDThreshold"]
    last3 = hist[-3:] if len(hist) >= 3 else hist
    metric_drift = len(last3) == 3 and all(x < threshold for x in last3)
    verdict = "KEEP" if not metric_drift else "TUNE"
    Path("canon/decision.json").write_text(json.dumps({"verdict": verdict, "threshold": threshold, "history": last3}, ensure_ascii=False, indent=2), encoding="utf-8")
print("Decision written → canon/decision.json")
