import unittest, tempfile, os, json, sys
from pathlib import Path as _P
sys.path.insert(0, str((_P(__file__).resolve().parents[1] / 'src').resolve()))
from pathlib import Path
from iskra_core.memory_manager import MemoryManager

class TestMemoryManagerCore(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        base = Path(self.tmp.name)
        self.archive = str(base / "archive.jsonl")
        self.shadow = str(base / "shadow.jsonl")
        self.mm = MemoryManager(self.archive, self.shadow)

    def tearDown(self):
        self.tmp.cleanup()

    def test_append_and_list_archive(self):
        self.mm.append_archive({"title":"t","type":"заметка","content":"ok","owner":"me","confidence":"средняя"})
        data = self.mm._load_jsonl(self.archive)
        self.assertEqual(len(data), 1)
        self.assertEqual(data[0]["title"], "t")

    def test_search_archive_by_owner(self):
        self.mm.append_archive({"title":"a","type":"заметка","content":"x","owner":"me","confidence":"высокая"})
        self.mm.append_archive({"title":"b","type":"заметка","content":"y","owner":"you","confidence":"низкая"})
        res = self.mm.search_archive(owner="me")
        self.assertTrue(all(r["owner"]=="me" for r in res))

    def test_shadow_flow(self):
        self.mm.append_shadow({"title":"s","signal":"drift","pattern":"p","hypothesis":"h","counter":"c","confidence":"средняя","owner":"me"})
        res = self.mm.search_shadow(signal="drift")
        self.assertEqual(len(res), 1)

if __name__ == "__main__":
    unittest.main()
