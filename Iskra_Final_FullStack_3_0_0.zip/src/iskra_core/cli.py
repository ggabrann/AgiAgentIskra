"""
iskra_core.cli - небольшой CLI для операций над памятью Искры.
"""
import argparse, json, sys
from pathlib import Path
from .memory_manager import MemoryManager

def main() -> None:
    p = argparse.ArgumentParser(prog="iskra-memory", description="AgiAgent Искра — операции памяти")
    p.add_argument("--archive", default="builds/projects/memory/ARCHIVE/main_archive.jsonl")
    p.add_argument("--shadow",  default="builds/projects/memory/SHADOW/main_shadow.jsonl")
    sub = p.add_subparsers(dest="cmd", required=True)
    add = sub.add_parser("add-archive")
    add.add_argument("--title", required=True)
    add.add_argument("--type", default="заметка")
    add.add_argument("--content", required=True)
    add.add_argument("--owner", default="system")
    add.add_argument("--tags", nargs="*", default=[])
    add.add_argument("--confidence", default="средняя")
    ls = sub.add_parser("list-archive")
    ls.add_argument("--owner", default=None)
    args = p.parse_args()

    mm = MemoryManager(args.archive, args.shadow)

    if args.cmd == "add-archive":
        entry = {
            "title": args.title,
            "type": args.type,
            "content": args.content,
            "owner": args.owner,
            "tags": args.tags,
            "confidence": args.confidence
        }
        mm.append_archive(entry)
        print("Записано:", json.dumps(entry, ensure_ascii=False))
    elif args.cmd == "list-archive":
        recs = mm.search_archive(owner=args.owner) if args.owner else mm._load_jsonl(args.archive)
        print(json.dumps(recs[-20:], ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
