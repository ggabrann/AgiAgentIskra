# SECURITY

- Не хранить PII, секреты, токены.
- Уязвимости сообщать через GitHub Security Advisories или security@example.com.
- Проверки: `make security`, `python tools/map_aliases.py --check`.
